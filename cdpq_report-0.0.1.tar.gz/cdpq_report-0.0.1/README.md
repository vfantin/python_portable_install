
To venv
.\venv\Scripts\activate

To git 
git add -A  
git commit -m 'Manage sql from xml & cleanup'  
git push -u --force origin master  

To build a distribution  
python.exe -m pip install --upgrade build  
python.exe -m build  


pip install file:C:\Users\fantv\AppData\Local\Programs\python_project\cdpq_utils\dist\cdpq_utils-0.0.7.tar.gz


Example from : https://agea.github.io/tutorial.md/

#Report is a tool to build html report and send it by mail.
#All the configuration must be in a config file.
#All the data are loaded from an sql directory.
#Jinja use this data to build a result file from a template file.
#report.ps1 take only one parameter, the path for the config file to use. 

