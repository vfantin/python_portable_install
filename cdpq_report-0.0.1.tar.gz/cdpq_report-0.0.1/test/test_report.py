import logging.config
import unittest
import datetime
import os
import filecmp

from pathlib import Path


import cdpq_utils.db_request_from_xml 
from cdpq_report.report import report
from cdpq_utils.config import load_config
from cdpq_utils.log import init_logging
from cdpq_utils.db_advanced_mock import mock_input_data

logger = logging.getLogger(__name__)

class Testreport(unittest.TestCase):
    
    def testcase01(self):
        report_file_path = build_output_data(fr'.\test\testcase01\config\ecosystem_drm.config')
        compare_to_mock(fr'.\test\testcase01\config\ecosystem_drm_mock.config',report_file_path)
        
    def testcase02(self):
        report_file_path = build_output_data(fr'.\test\testcase02\config\markit_detail.config')
        compare_to_mock(fr'.\test\testcase02\config\markit_detail_mock.config',report_file_path)

        
def compare_to_mock(mock_config_file_path, report_file_path):
    #Get the mock export file path to compare 
    mock_config_file = load_config(mock_config_file_path)
    mock_file_path = eval(mock_config_file['report']['report_file_path'])
    
    #Compare
    result = filecmp.cmp(mock_file_path, report_file_path)
    if(result):
        logger.info(fr'File {report_file_path} is OK.')
    else:
        raise AssertionError(fr'{report_file_path} is not equal to {mock_file_path}')


def build_output_data(report_config_file_path):
    #Build a new output report
    #config_file_path = fr'.\test\testcase02\config\markit_detail.config'
    report_config_file = load_config(report_config_file_path)
    mock_input_directory = report_config_file['mock']['mock_input_directory']
    
    cdpq_utils.db_request_from_xml.global_mock_directory = mock_input_directory
    report_file_path = report(report_config_file_path)
    cdpq_utils.db_request_from_xml.global_mock_directory = None
    return report_file_path

def mock_test_case(mock_config_file):
    mock_config = load_config(mock_config_file)
    if(mock_config.has_section('log')):
        init_logging(mock_config['log'].get('logging_file_path'))
    mock_input_data(mock_config)
    build_output_data(mock_config_file)

if __name__ == '__main__':
    
    #mock_test_case(fr'.\test\testcase01\config\ecosystem_drm_mock.config')
    #mock_test_case(fr'.\test\testcase02\config\markit_detail_mock.config')
    unittest.main()
    #unittest.main(argv=['-k','Testreport.testcase02'])