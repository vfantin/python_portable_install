import os
import logging.config
import unittest
import filecmp
from pathlib import Path
from shutil import rmtree


from cdpq_utils.db_mock import load_mock_from_file
from cdpq_report.graph import graph_xdaily_basis
from cdpq_utils.db_advanced_mock import mock_input_data
from cdpq_utils.config import load_config,init_config
import cdpq_utils.db_request_from_xml 

logger = logging.getLogger(__name__)


class Test_graph(unittest.TestCase):

    def test_graph_xdaily_basis(self):
  
        mock_config_file = fr'.\test\tc_graph\config\mock.config'
        mock_config = load_config(mock_config_file)
        mock_output_directory = mock_config['mock']['mock_output_directory']
        
        testcase_config_file = fr'.\test\tc_graph\config\testcase.config'
        testcase_config = load_config(testcase_config_file)
        testcase_output_directory = testcase_config['mock']['mock_output_directory']
        
        build_output_data(testcase_config)
        
        all_files = [f for f in Path(testcase_output_directory).glob('**\*') if f.is_file() and f.suffix in {'.png'}]
        if(len(all_files) < 1):
            logger.warning(f'{mock_input_directory} is empty !!')
            self.assertEqual(False, True)

        for file_path in sorted(all_files):
            mock_output_file = os.path.join(mock_output_directory,Path(file_path).stem+'.png')
            result = filecmp.cmp(mock_output_file,file_path)
            if(result):
                logger.info(fr'File {file_path} is OK.')
            else:
                logger.warning(fr'{mock_output_file} is not equal to {file_path}')
            self.assertEqual(result, True)


def build_output_data(config):
    mock_input_directory = config['mock']['mock_input_directory']
    mock_output_directory = config['mock']['mock_output_directory']

    cdpq_utils.db_request_from_xml.global_mock_directory = mock_input_directory
    
     #mock_input_data(mock_config)
    #To build output from mock
    all_files = [f for f in Path(mock_input_directory).glob('**\*') if f.is_file() and f.suffix in {'.mock'}]
    if(len(all_files) < 1):
        logger.warning(f'{mock_input_directory} is empty !!')
        
    for file_path in sorted(all_files):
        graph_xdaily_basis(os.path.join(mock_output_directory,Path(file_path).stem+'.png'), load_mock_from_file(file_path),True)
    
    cdpq_utils.db_request_from_xml.global_mock_directory = None
    

if __name__ == '__main__':
    
    #To build mock from mock data
    mock_config_file = fr'.\test\tc_graph\config\mock.config'
    mock_config = init_config(mock_config_file)
    mock_input_directory = mock_config['mock']['mock_input_directory']

    mock_input_data(mock_config)
    build_output_data(mock_config)
   
    unittest.main()
    #unittest.main(argv=['-k','Testdb_utils.test_graph_xdaily_basis'])