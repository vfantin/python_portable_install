
import os
import sys
import argparse

import logging.config;
import datetime as dt

from datetime import datetime
from datetime import timedelta

from pathlib import Path
from jinja2 import Environment, FileSystemLoader,select_autoescape

from cdpq_utils.mail import mail_html_file
from cdpq_utils.db_request_from_xml import execute_sql_directory
from cdpq_utils.config import init_config
from cdpq_utils.db_request import load_db_configuration
from cdpq_report.graph import graph_xdaily_basis

logger = logging.getLogger(__name__)

#If we want to properly add picture inside a mail !
img_content = {}

config = None
all_data = None

#Magic this function have a direct access to config and all_data !
#But if we use build function from a main in an another file .. it doesn't work
#So graph dosesn't work in test_build_report ... 
#I declare config & all_data global variables and I remove them fron arguments
def graph(dataset_name,legend,timestamp):
    report_directory = os.path.split(config['report']['report_file_path'])[0]

    #This option is useful to generate excatly same report file with no timestamp difference
    #Useful for test !
    if(timestamp):
        file_name = dataset_name +'_'+dt.datetime.now().strftime('%Y%m%d%H%M%S') + '.png'
    else:
        file_name = dataset_name + '.png'

    graph_xdaily_basis(os.path.join(report_directory,file_name),all_data[dataset_name],legend)
    if(config.has_section('mail')):
        img_content.update({file_name:os.path.join(report_directory,file_name)})
        return f'cid:{file_name}'
    else:
        return file_name

def init(config_file_path):
    global config, all_data
    config = init_config(config_file_path)
    
    sql_params = None
    if(config.has_section('sql')):
        sql_params = {param:eval(config['sql'][param]) for param in config['sql']}
    
    #Evaluate report_file_path
    config['report']['report_file_path'] = eval(config['report']['report_file_path'])
    
    #Load all the data
    logger.info(f"Load data from {config['report']['request_directory']} with {sql_params}." )
    #all_data = execute_standalone_sql_directory(config['report']['request_directory'], sql_params)
    all_data = execute_sql_directory(config['report']['request_directory'], sql_params)
    
    #Not necessary since this variables are globals
    #return config, all_data

def build():
    
    report_file_path = config['report']['report_file_path'] 
    template_file_path = config['report']['template_file_path'] 
    
    env = Environment(loader = FileSystemLoader(os.path.split(template_file_path)[0]),autoescape=select_autoescape())
    env.globals.update(graph=graph)
    template = env.get_template(os.path.split(template_file_path)[1])
    
    logger.info(f"Build report {report_file_path} from template {template_file_path}." )
    Path(report_file_path).write_text(template.render(all_data))
    return report_file_path

def send(report_file_path):
    if(config.has_section('mail')):
        mail_from = config['mail']['mail_from']
        mail_list = config['mail']['mail_list']
        subject = eval(config['mail']['subject'])
        mail_html_file(report_file_path,mail_from,mail_list,subject,img_content)

def report(config_file):
    init(config_file)
    report_file_path = build()   
    send(report_file_path)
    return report_file_path
    
if __name__ == "__main__":
    try:
        parser = argparse.ArgumentParser(description='Generate & send generic report.')
        parser.add_argument('-config_file', type=str, help='Standard config file.')
        args = parser.parse_args()
        if(args.config_file is None or args.config_file==''):raise Exception(f'Must have config_file argument')
        if(not os.path.isfile(args.config_file)):raise Exception(f'config_file: {args.config_file} must be a valid file path !')
        
        report(args.config_file)
    
    except Exception as e:
        logger.info('Failure !!')    
        logger.error(e)
        sys.exit(2)
    
    logger.info('Success !!')    
    sys.exit(0)
    