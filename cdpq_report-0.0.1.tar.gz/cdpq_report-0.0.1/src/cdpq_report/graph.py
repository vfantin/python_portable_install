import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import os
import datetime as dt


def graph_xdaily_basis(file_path, rows,legend):
    
    #if(file_name is None): 
    #    file_name = dt.datetime.now().strftime('%Y%m%d%H%M%S%f')+'.png'

    #At least two columns, first one must be date type
    if(rows is None or len(rows) <= 0): raise Exception('No data to build a graph!')
    if(type(rows[0][0]) != dt.date): raise Exception('First column must be datetime.date')

    nb_curves = len(rows[0].cursor_description)-1
    
    dates = [row[0] for row in rows]
    #Other columns are data !
    curves = [[row[i+1] for row in rows] for i in range(nb_curves)]
    
    fig, ax = plt.subplots()  # Create a figure containing a single axes.
    #Use colummn's name to create label/legend
    for i in range(len(curves)):
        ax.plot(dates, curves[i], label = rows[0].cursor_description[i+1][0])

    if(legend):
        plt.legend(bbox_to_anchor=(1,1), loc="upper left")
    
    #I prefer like this
    plt.margins(0.01)
    ax.xaxis.set_major_locator(mdates.WeekdayLocator(dates[0].weekday()))
    ax.xaxis.set_major_formatter(mdates.DateFormatter('%m-%d'))
    ax.xaxis.set_minor_locator(mdates.DayLocator())
    for label in ax.get_xticklabels(which='major'):
        label.set(rotation=30, horizontalalignment='right')
    
    
    
    plt.savefig(file_path,bbox_inches='tight')
    return file_path