#To avoid issue with different venv, use the good one and avoid to lost it with deactivate, you can use
#Powershell.exe -WindowStyle Hidden .\environment\dev\ecosystem_drm\report.ps1 .\config\ecosystem_drm_yesterday.config
#Like this Activate.ps1 and deactivate are ineffective on your current powershell session
#Config files use relatif path so this is a avoid error if someone wants to execute this file from another location!
Push-Location $PSScriptRoot 
if (!($args.Count -eq 1)) {throw "Must supply only one config file argument."}
C:\apps\edrm\dev\report\drm\venv\Scripts\Activate.ps1
Write-Host "python.exe -m cdpq_report.report -config_file=$($args[0])"
python.exe -m cdpq_report.report -config_file="$($args[0])"
deactivate
Pop-Location
