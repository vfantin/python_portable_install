# Rapport DRM 0.0.1
Le rapport DRM utilise le module python *cdpq.report* pour :
- récupèrer les erreurs dans logs BDs des composantes ACD, DRM_INT, MARKIT et EDRM 
- créer une page html de rapport à partir d'un modèle et des données collectées.
- envoyer le résultat par courriel.  

Toutes les requêtes dans les BDs sont faites pour aller chercher les erreurs entre deux dates.

## Configuration globale

La configuration globale se trouve directement dans le répertoire config.  
La configuration contient quatre sections :  
- [sql] pour les paramètres nécessaires aux requêtes SQL  
- [report] pour la configuration qui permet de générer le rapport à partir d'un modèle (grâce à la librairie JINJA2) 
- [mail] pour configurer les paramètres du courriel  
- [log] pour configurer le niveau de log :-)  

Il y a deux fichiers de configurations pour générer deux rapports à partir de paramètres sql différents :  
- today_drm_report.config qui va chercher les erreurs pour la journée en cours.
- yesterday_drm_report.config qui va chercher les erreurs pour la journée d'hier.

## Configuration sql
La configuration des requêtes sql sur les différentes base de données se trouve dans le répertoire *config\sql*.
La documentation des requêtes se trouve avec les requêtes à l'intérieur des fichiers xml.
Le fichier drm_int.xml contient les requêtes vers la BD DRM_INT mais aussi une requête vers la BD ACD.
Cela permets d'identifier les fichiers configurés critiques dans ACD et d'extraire uniquement les erreurs DRM_INT en lien avec ces fichiers là.

## Configuration du modèle de rapport
La modèle utilisé pour la page html se trouve dans le fichier *config\template\drm.html*.  
Le fichier *macro_print_table.html* est une macro qui va être utilisée plusieurs fois dans la page *drm.html* pour afficher tous les tableaux de résultats.

## Configuration Autosys
La configuration pour installer la planification dans Autosys se trouve dans *config\autosys*.  
Il y a une configuration pour extraire le rapport en date du jour (4 fois par jour) dans le fichier : *today_drm_report.jil*.  
Il y a une configuration pour extraire le rapport en date d'hier (1 fois par jour) dans le fichier  : *yesterday_drm_report.jil*  

