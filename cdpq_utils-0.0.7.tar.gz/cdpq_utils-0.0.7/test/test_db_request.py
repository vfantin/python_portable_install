import logging.config
import unittest
import pyodbc

import UtilsTestCase 
from cdpq_utils.db_request import execute_sql,fetch_sql,open_connexion,close_connexion,load_db_configuration

logger = logging.getLogger(__name__)

class Test_db_request(UtilsTestCase.UtilsTestCase):

    #Need to have a create/update/delete rights on DB
    def test_execute_sql(self):
        raised_exception = False
        try:
            execute_sql(self.db_name,'DROP TABLE IF EXISTS TEST1')
            execute_sql(self.db_name,'CREATE TABLE TEST1(COL1 INT)')
            execute_sql(self.db_name,'INSERT INTO TEST1 VALUES (1),(2),(5)')
            execute_sql(self.db_name,'DELETE FROM TEST1')
            execute_sql(self.db_name,'DROP TABLE TEST1')
        except Exception as ex:
             raised_exception = True
        self.assertFalse(raised_exception)    
    
    def test_fetch_sql(self):
        res= fetch_sql(self.db_name,'SELECT 1')
        self.assertEqual(res[0][0],1)

    def test_reuse_connexion(self):
        
        #If we d'ont open a connexion temporary table are not accessible 
        #to the next fetch
        execute_sql(self.db_name,'SELECT 1 AS C INTO #TEST1')
        try:
            fetch_sql(self.db_name,'SELECT * FROM #TEST1')
        except Exception as ex:
            exception = ex    
        self.assertIsInstance(exception, pyodbc.ProgrammingError)
        
        #But if we open a connexion, it should work
        open_connexion(self.db_name)
        execute_sql(self.db_name,'SELECT 1 AS C INTO #TEST1')
        res = fetch_sql(self.db_name,'SELECT * FROM #TEST1')
        self.assertEqual(res[0][0],1)
        close_connexion(self.db_name)

if __name__ == '__main__':
    #unittest.main()
    unittest.main(argv=['-k','Test_db_request.test_reuse_connexion'])
    

    