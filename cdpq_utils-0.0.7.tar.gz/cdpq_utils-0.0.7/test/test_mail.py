import logging.config
import os
import unittest

import UtilsTestCase 
from cdpq_utils.log import init_logging
from cdpq_utils.config import init_config

from cdpq_utils.mail import mail_html_file

logger = logging.getLogger(__name__)

class Test_mail(UtilsTestCase.UtilsTestCase):

    def test_mail(self):

        mock_directory = fr'.\test\tc_mail\mock_input_data'
        mail_from = 'a_dvedrm_bacth@cdpq.com'
        mail_list = 'vfantin@cdpq.com'
        subject = 'Test email with picture login'
        report_file_path = os.path.join(mock_directory,'report_2021-12-21.html')

        img_content = {'image1':os.path.join(mock_directory,'20211222155319.png'),
                       'image2':os.path.join(mock_directory,'20211222155320.png')}
        mail_html_file(report_file_path,mail_from,mail_list,subject,img_content)

if __name__ == '__main__':
    unittest.main()
    #unittest.main(argv=['-k','Testdb_utils.test_mail'])
    

    