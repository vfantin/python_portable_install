import os
import logging.config
import unittest

import UtilsTestCase
import tempfile


from cdpq_utils.db_mock import dump_rows_to_file, load_mock_from_file
from cdpq_utils.db_request  import fetch_sql

logger = logging.getLogger(__name__)


class Testdb_mock(UtilsTestCase.UtilsTestCase):

    def test_mock(self):

        file_path = os.path.join(tempfile.gettempdir(), 'test_mock.mock')

        # We have to name eack column !
        #Path(file_path).write_text(
        #    f"{PARAMS_PATTERN}{{'db_name':'TEST','command_type':'select'}}\nSELECT 1 AS COL1")
        rows = fetch_sql(self.db_name, 'SELECT 1 AS COL1')

        # Build a mock from the sql command file
        dump_rows_to_file(file_path, rows)
        self.assertTrue(os.path.isfile(file_path))

        # Execute the mock !
        mock = load_mock_from_file(file_path)
        # Compare with the result from the original sql file
        self.assertEqual(rows, mock)
        os.remove(file_path)

    def test_mock_all_types(self):

        file_path = os.path.join(tempfile.gettempdir(), 'test_mock_all_types.mock')

        # We have to name eack column !
        sql = (f"SELECT CONVERT(bit, 0) C_BIT,1 C_INT,2.3 C_DECIMAL,"
            "'abcdef' C_VARCHAR,CAST(128 AS BINARY(4)) C_BINARY,"
            "CONVERT(DATE,'2001-01-01') C_DATE,CONVERT(TIME,'13:00:01') C_TIME, CONVERT(DATETIME,'2001-01-01 13:00:01.007') C_DATETIME")

        res = fetch_sql(self.db_name, sql)

        # Strange fact ... bug in the odbcdriver ?!
        # print(res[0].cursor_description[4][1])--><class 'bytearray'>
        # print(type(res[0][4]))--><class 'bytes'>

        # Build a mock from the sql command file
        dump_rows_to_file(file_path, res)
        self.assertTrue(os.path.isfile(file_path))

        # Execute the mock !
        mock = load_mock_from_file(file_path)
        # Compare with the result from the original sql file
        self.assertEqual(res, mock)

        os.remove(file_path)


if __name__ == '__main__':
    unittest.main()
    #unittest.main(argv=['-k','Testdb_mock.test_mock_all_types'])
