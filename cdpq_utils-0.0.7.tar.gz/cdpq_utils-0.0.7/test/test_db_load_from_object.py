import logging.config
import unittest
import datetime
import os
from pathlib import Path

import UtilsTestCase
from cdpq_utils.db_request import execute_sql,fetch_sql,open_connexion,close_connexion
from cdpq_utils.db_load_from_object import create_table,insert
from cdpq_utils.db_mock import load_mock_from_file

logger = logging.getLogger(__name__)

class Testdb_request_from_object(UtilsTestCase.UtilsTestCase):

    def test_insert(self):
        
        open_connexion(self.db_name)
        #Create the temporary table #TEST1
        execute_sql(self.db_name,'SELECT * INTO #TEST1 FROM (VALUES (1,GETDATE()),(2,GETDATE())) T1 (c1,c2)')
        #Build a fetch
        day = datetime.date(2021, 1, 1)
        res = fetch_sql(self.db_name,f"SELECT 3 AS c1, '{day}' as c2")
        #Try to load dataset
        insert(self.db_name,'#TEST1',res)
        res = fetch_sql(self.db_name,"SELECT C1, FORMAT(C2,'yyyy-MM-dd') FROM #TEST1 ORDER BY 1")
        
        self.assertEqual(len(res),3)
        self.assertEqual(res[2][1],f'{day}')

        close_connexion(self.db_name)
    
    # def test_insert_performance(self):
    #     #A mock file with 309 lines
    #     file_path = os.path.join(self.mock_directory,'test_load_performance.mock')
        
    #     open_connexion(self.db_name)
    #     execute_sql(self.db_name,'CREATE TABLE #ACD_CRITICAL_FILES_RECEIVED ( FileKey NVARCHAR(256), ExecutionDate DATETIME2,FileValueDate DATETIME)')
    #     rows = load_mock_from_file(file_path)
        
    #     insert('TEST','#ACD_CRITICAL_FILES_RECEIVED',rows)
    #     rows = fetch_sql(self.db_name,'SELECT * FROM #ACD_CRITICAL_FILES_RECEIVED')
    #     self.assertEqual(len(rows),309)
        
    #     close_connexion(self.db_name)

    #Basic test, we read from a table a row we try to dynamically create a table from it
    #And we insert the same row in the new table ...
    def test_create_table(self):

        open_connexion(self.db_name)

        execute_sql(self.db_name,'CREATE TABLE #T1 (C1 INT, C2 BIGINT , C33 TINYINT,C34 FLOAT,C3 NUMERIC(18,12), C4 BIT, '\
                                    'C5 CHAR, C6 NVARCHAR(5), C7 VARCHAR(36), C77 TEXT, '\
                                    'C8 DATETIME2, C9 DATETIME, C11 SMALLDATETIME, C12 DATE, C10 TIME  )')
        execute_sql(self.db_name,"INSERT INTO #T1 VALUES (1, 123456789, 1, 3.4,5.6,0,'a','abcd','abcd','Long text',"\
        "'2021-12-12','2021-12-12','2021-12-12','2021-12-12','2021-12-12')")
        row1 = fetch_sql(self.db_name,'SELECT * FROM #T1')[0]
        
        create_table(self.db_name,"#T2",row1.cursor_description)
        
        #To see structure from #T1 and #T2
        # cur = cdpq.utils.db.get_connexion(self.db_name).execute('SELECT * FROM #T1')
        # for col in cur.description:
        #      print(col)
        # cur = None #Free connexion but not close
        # cur = cdpq.utils.db.get_connexion(self.db_name).execute('SELECT * FROM #T2')
        # for col in cur.description:
        #      print(col)

        execute_sql(self.db_name,"INSERT INTO #T2 VALUES (2, 123456789, 1, 3.4,5.6,0,'a','abcd','abcd','Long text',"\
        "'2021-12-12','2021-12-12','2021-12-12','2021-12-12','2021-12-12')")
        row2 = fetch_sql(self.db_name,'SELECT * FROM #T2')
        
        self.assertEqual(len(row2),1)
        
        close_connexion(self.db_name)

  

if __name__ == '__main__':
    unittest.main()
    #unittest.main(argv=['-k','Testdb_request_from_object.test_insert_performance'])
    

    