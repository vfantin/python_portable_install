import logging.config
import unittest
import time


import UtilsTestCase
from cdpq_utils.db_request import execute_sql
import cdpq_utils.db_request as db_request
import cdpq_utils.connexion_manager as connexion_manager


from working_factory import WorkingFactory

logger = logging.getLogger(__name__)

def do_request(param):
    logger.info(f"Wait {param['wait']} before {param['request']}")
    time.sleep(param['wait'])
    execute_sql(param['db_name'],param['request'])

class Testdb_manager(UtilsTestCase.UtilsTestCase):
    
    def test_max_attempt(self):
        
        #Add decorator dynamically !!
        execute_sql = connexion_manager.manage_connection(db_request.execute_sql)
        fetch_sql = connexion_manager.manage_connection(db_request.fetch_sql)

        execute_sql(self.db_name,'DROP TABLE IF EXISTS TEST1')
        
        connexion_manager.management_is_active = True
        connexion_manager.max_retry = 2
        connexion_manager.waiting_time = 1
        connexion_manager.nb_error = 0

        try:
            fetch_sql(self.db_name,'SELECT * FROM TEST1')
        except Exception as ex:
            pass
        #We have max_retry + 1 errors !!
        self.assertEqual(connexion_manager.nb_error,connexion_manager.max_retry+1)
        
    def test_manage_exception(self):

        #Add decorator dynamically !!
        execute_sql = connexion_manager.manage_connection(db_request.execute_sql)
        fetch_sql = connexion_manager.manage_connection(db_request.fetch_sql)

        execute_sql(self.db_name,'DROP TABLE IF EXISTS TEST1')
        
        connexion_manager.management_is_active = True
        connexion_manager.waiting_time = 1
        #Should be > 1
        expected_error = 3
        
        #We will wait to create the table after expected_attempt select
        wait_before_request = connexion_manager.waiting_time * expected_error 
        connexion_manager.max_retry = expected_error - 1
        
        connexion_manager.nb_error = 0
        wf = WorkingFactory(1,do_request)
        wf.add_work({'wait':wait_before_request,'db_name':self.db_name,'request':'CREATE TABLE TEST1(COL1 INT)'})
        
        try:
            fetch_sql(self.db_name,'SELECT * FROM TEST1')
        except Exception as ex:
            pass

        self.assertEqual(connexion_manager.nb_error,expected_error)
        
        wf.wait_eow()

        execute_sql(self.db_name,'DROP TABLE IF EXISTS TEST1')

if __name__ == '__main__':
    unittest.main()
    #unittest.main(argv=['-k','Testdb_utils.test_manage_exception'])
    

    