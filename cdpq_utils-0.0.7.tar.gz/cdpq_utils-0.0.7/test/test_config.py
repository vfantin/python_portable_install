import logging.config
import unittest
import os

import UtilsTestCase 
from cdpq_utils.config import load_config

logger = logging.getLogger(__name__)

class Test_config(UtilsTestCase.UtilsTestCase):

    #Need to have a create/update/delete rights on DB
    def test_load_config(self):
        
        os.environ["INSTALL_PATH2"] = 'path2'

        config = load_config(fr'.\test\config\test.config')
        
        self.assertEqual(config['test_load_config']['INSTALL_PATH1'], 'path1')

        self.assertEqual(config['test_load_config']['INSTALL_PATH2'], 'path2')


        return True
if __name__ == '__main__':
    #unittest.main()
    unittest.main(argv=['-k','Test_config.test_load_config'])
    

    