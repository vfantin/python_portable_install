# Example Package

This is a simple example package. You can use
[Github-flavored Markdown](https://guides.github.com/features/mastering-markdown/)
to write your content.

To venv  
.\venv\Scripts\Activate.ps1  

To git 
git add -A  
git commit -m 'Manage sql from xml & cleanup'  

git commit -am 'Manage sql from xml & cleanup'
git push -u --force origin master  
  
To build a distribution  
python.exe -m pip install --upgrade build  
python.exe -m build  
