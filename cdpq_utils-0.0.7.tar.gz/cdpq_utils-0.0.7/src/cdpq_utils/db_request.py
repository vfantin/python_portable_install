import logging.config
import pyodbc 
from cdpq_utils.config import load_config

logger = logging.getLogger(__name__)

db_configuration = {}

opened_connexion = {}

#With the db_request_from_xml we don't need to manage the config from an extern file config !
#But in some case it's very useful
def load_db_configuration(config_file_path, section_name):
    cnx_config = load_config(config_file_path)
    if(cnx_config == None or not cnx_config.has_section(section_name)): raise Exception(f"Global config doesn't contain {section_name} section")
    for key in cnx_config[section_name]:
        db_configuration[key] = cnx_config[section_name][key]
    return db_configuration

#To keep connexion open we just keep it inside a dictonnary
#In this case the connection is never close and we can use temporary table !
#Connexion must be configured (inside db_configuration)   
def open_connexion(db_name):
    if(opened_connexion.get(db_name) is None):    
        opened_connexion[db_name] = pyodbc.connect(db_configuration[db_name])
    else:
        logger.warning(f'{db_name} is already open.')
    return opened_connexion[db_name]

def close_connexion(db_name):
    cnx = opened_connexion.get(db_name)
    if(cnx is None):    
        logger.warning(f'{db_name} is not open.')
    else:
        cnx.close()
        opened_connexion.pop(db_name)

#If the connexion exists in opened_connexion, we use it
#Else we just open a one-time connexion and return it !
#Generally we don't use an opened connexion, but it can be useful with temporary tables in rare cases.
def get_connexion(db_name):
    cnx = opened_connexion.get(db_name)
    if(cnx is None):
        cnx = pyodbc.connect(db_configuration[db_name])
    return cnx

#After a lot of fun, I think we don't have to manage connection !!
#@manage_connection
def execute_sql(db_name, sql, commit = True):
    cursor = get_connexion(db_name).cursor()
    logger.debug(f'{db_name} EXECUTE: {sql}')
    res = cursor.execute(sql) 
    if(commit): cursor.commit()
    return res 

#@manage_connection
def executemany_sql(db_name, sql, params, commit = True):
    cursor = get_connexion(db_name).cursor()
    logger.debug(f'{db_name} EXECUTEMANY: {sql}')
    res = cursor.executemany(sql, params) 
    if(commit): cursor.commit()
    return res 

#@manage_connection
def fetch_sql(db_name, sql):
    cursor = get_connexion(db_name).cursor()
    logger.debug(f'{db_name} SELECT: {sql}')
    cursor.execute(sql) 
    return cursor.fetchall()
