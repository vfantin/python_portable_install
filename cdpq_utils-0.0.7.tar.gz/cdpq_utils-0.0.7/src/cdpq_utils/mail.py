import logging.config
import smtplib
from email.mime.text import MIMEText
from email.message import EmailMessage
from email.mime.multipart import MIMEMultipart
from email.mime.image import MIMEImage
#from email.utils import make_msgid

#import win32com.client

from pathlib import Path

logger = logging.getLogger(__name__)

#https://fr.wikipedia.org/wiki/Multipurpose_Internet_Mail_Extensions#alternative
#Construct an email multipart from an html file path and a list of dictionnary {ImageID:image_file_path} 
def mail_html_file(html_file_path, from_adress, mailing_list, subject, img_content = {}):
    msgRoot = MIMEMultipart('related')
    msgRoot['Subject'] = subject
    msgRoot['From'] = from_adress
    msgRoot['To'] = mailing_list
    msgRoot.preamble = 'Multi-part message in MIME format.'

    msgAlternative = MIMEMultipart('alternative')
    msgRoot.attach(msgAlternative)

    msgText = MIMEText('Alternative plain text message.')
    msgAlternative.attach(msgText)

    msgText = MIMEText(Path(html_file_path).read_text(),'html')
    msgAlternative.attach(msgText)

    #Attach Image 
    for cid,html_file_path in img_content.items():
        #fp = open(file_path, 'rb') #Read image 
        msgImage = MIMEImage(Path(html_file_path).read_bytes())
        msgImage.add_header('Content-ID', f'<{cid}>')
        msgRoot.attach(msgImage)

    # Send the message via our own SMTP server.
    s = smtplib.SMTP('smtp.lacaisse.com')
    #connect_to_exchange_as_current_user(s)
    logging.info(f"Send email to {msgRoot['To']}")
    s.send_message(msgRoot)
    s.quit()

#win32com maybe useful one day ... 
# But for now, we can set From attribute , it seems the API use by default the current user
# It could be practise to read the current outlook email for testing a real sending
# def outlook_html_file(file_path, from_adress, mailing_list, subject):
#         #Outlook.Application outlookApp = new Outlook.Application();
            
#         outlookApp = win32com.client.Dispatch("Outlook.Application")
#         #Create an email but we can create some other things !
#         mailItem = outlookApp.CreateItem(0)
        
        
#         mailItem.Subject = subject
#         mailItem.To = mailing_list
        
#         imageSrc = fr'C:\Users\fantv\Documents\python\project\cdpq_utils\tests\data\20211221161100.png'
#         attachments = mailItem.Attachments;
#         attachment = attachments.Add(imageSrc);
#         attachment.PropertyAccessor.SetProperty("http://schemas.microsoft.com/mapi/proptag/0x370E001F", "image/png");
#         #// Image identifier found in the HTML code right after cid. Can be anything.
#         attachment.PropertyAccessor.SetProperty("http://schemas.microsoft.com/mapi/proptag/0x3712001F", "myident"); 
#         mailItem.PropertyAccessor.SetProperty("http://schemas.microsoft.com/mapi/id/{00062008-0000-0000-C000-000000000046}/8514000B", True)

#         #// Set body format to HTML
        
#         #mailItem.BodyFormat = win32com.client.constants.olFormatHTML
#         #msgHTMLBody = "<html><head></head><body>Hello,<br><br>This is a working example of embedding an image unsing C#:<br><br><img align=\"baseline\" border=\"1\" hspace=\"0\" src=\"cid:myident\" width=\"\" 600=\"\" hold=\" /> \"></img><br><br>Regards,<br>Tarik Hoshan</body></html>";
#         msgHTMLBody = Path(file_path).read_text()
#         mailItem.HTMLBody = msgHTMLBody
#         mailItem.Send()