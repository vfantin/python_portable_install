import pyodbc
from pathlib import Path
import os
# Need to import this module for the eval function
import datetime
# str(list) use repr ! https://www.python.org/dev/peps/pep-3140/
# type(Decimal) returns <class 'decimal.Decimal'> so like for datetime we have to import the module
import decimal
# But Decimal repr is Decimal(XXX.YYYY) so you have to import directly the class Decimal
# if you want eval works on the row line
from decimal import Decimal


#A hack to create a pyofbc row !
#How to create a row ... I read code from function Row_new
#https://github.com/mkleehammer/pyodbc/blob/master/src/row.cpp
#Find the function with the PyTypeObject
#https://docs.python.org/3/c-api/typeobj.html#cols
#Most important is inside Row* Row_InternalNew(PyObject* description, PyObject* map_name_to_index, Py_ssize_t cValues, PyObject** apValues)
#I'm not sure where the first arg is used ? we should put a type or a subtype of pyodbc.Row
#description is Tuple[Tuple[str, Any, int, int, int, int, bool]] from file pyodbc.pyi
def load_mock_from_file(file_path):
    
    rows = []
    first_line = True
    for line in Path(file_path).read_text().splitlines():
        # We jump the comment lines wich start with --
        if(not line.strip().startswith('--')):
            # We use the first line to get row description & mapping
            if(first_line):
                # First line is the Row's description
                description = eval(line)
                # We suppose columns ordered
                mapping = {col[0]: idx for idx, col in enumerate(description)}
                first_line = False
            else:
                row_values = eval(line)
                rows.append(pyodbc.Row(description, mapping, *row_values))
    return rows

def dump_rows_to_file(file_path, rows):
    with open(file_path, 'w') as file:
        if(len(rows)<1):
            file.write(f'--Empty dataset\n')
        else:
            description = rows[0].cursor_description
            # Join all the column's representation
            # Dirty ?! we use string representation to determine python Class (see col[1])
            desc_to_str = ', '.join(
                [f"('{col[0]}',{repr(col[1])[8:-2]},{col[2]}, {col[3]}, {col[4]}, {col[5]}, {col[6]})" for col in description])
            #:-) Add a ',' when only a columnn ! it's the default  python's behaviour
            if(len(description) == 1):
                desc_to_str = desc_to_str + ', '
            desc_to_str = '('+desc_to_str+')'

            file.write(f"{desc_to_str}\n")
            for row in rows:
                file.write(f'{repr(row)}\n')
    return file_path

