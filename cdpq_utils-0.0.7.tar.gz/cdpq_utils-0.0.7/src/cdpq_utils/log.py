import os
import logging.config

logger = logging.getLogger(__name__)

init_logging = True
#Init only one time the loggin module.
#If logging_file_path is empty, we use a default configuration with INFO level
def init_logging(logging_file_path = None):
    global init_logging
    if(init_logging):
        if(logging_file_path is not None):
            #file_path = os.getenv('logging_config_file')
            #if(file_path != None): 
            if(not os.path.isfile(logging_file_path)): raise Exception(f'{logging_file_path} is not a file !!')
            #disable_existing_loggers to False permit the use of the logger from this file!
            #or we have to define the logger after this call ...
            logging.config.fileConfig(logging_file_path, disable_existing_loggers=False)
            logger.info(f'Load log config file {logging_file_path}')
            
        else:
            logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s - [%(thread)d]')
            logger.info('No logging.config.file ,we''ll use the default configuration !')
            
        init_logging = False
    else:
        logger.info('Init logging is already done !')