import os
import argparse
import logging.config
from pathlib import Path
from datetime import datetime

from shutil import copytree, rmtree, make_archive,unpack_archive
from cdpq_utils.config import init_config

logger = logging.getLogger(__name__)

def apply_template(src_directory_path,dst_directory_path,config):
    
    src_directory_name = os.path.split(src_directory_path)[-1]
    cp_directory_path = os.path.join(dst_directory_path,src_directory_name)

    if(os.path.exists(cp_directory_path)):
        logger.info(f'Remove dir : {cp_directory_path}')
        rmtree(dst_directory_path)
    
    logger.info(f'Copy {src_directory_path} to {cp_directory_path}')
    copytree(src_directory_path, cp_directory_path)

    for section in config.sections():
        if(section not in ('global_parameters','log')):
            file_path = os.path.join(cp_directory_path,section)
            if(os.path.isfile(file_path)): 
                text = Path(file_path).read_text(encoding='utf-8')
                for key,value in config[section].items():
                    logger.info('Inside '+file_path+' replace {'+key+'} by '+ value)
                    text = text.replace('{'+key+'}', value)
                Path(file_path).write_text(text,encoding='utf-8')
            else:
                logger.warning(f'{file_path} is not a file !!')

    return cp_directory_path

def zip_directory(src_directory_path,dst_directory_path = None):

    src_directory_name = os.path.split(src_directory_path)[-1]
    root_directory =  Path(src_directory_path).parent
    
    if(dst_directory_path is None): dst_directory_path = root_directory
    zip_file_path =  os.path.join(dst_directory_path,datetime.now().strftime(f"{src_directory_name}_%Y%m%d%H%M%S"))

    logger.info(f'Archive {os.path.join(root_directory,src_directory_name)} inside {zip_file_path}')
    
    make_archive(zip_file_path, 'zip', root_directory, src_directory_name)

    return zip_file_path +'.zip'

def deploy_config(config):
    template_directory =  config['global_parameters']['template_directory']
    build_directory =  config['global_parameters']['build_directory']
    
    backup_directory =  config['global_parameters']['backup_directory']
    deploy_directory =  config['global_parameters']['deploy_directory']
    
    #Template a directory inside a zip file
    dist_directory = apply_template(template_directory,build_directory,config)
    zip_file_path = zip_directory(dist_directory,build_directory)
    logger.info(f'Remove directory {dist_directory}')
    rmtree(dist_directory)

    #Backup the old one
    if(os.path.exists(deploy_directory)):
        logger.info(f'Backup directory {deploy_directory} inside {backup_directory}')
        bck_zip_file_path = zip_directory(deploy_directory, backup_directory)
        rmtree(deploy_directory)
    
    #Unzip the new one
    unpack_archive(zip_file_path,extract_dir=Path(deploy_directory).parent)

if __name__ == '__main__':

    parser = argparse.ArgumentParser(description='Generate & send generic report.')
    parser.add_argument('-config_file', type=str, help='Standard config file.')
    args = parser.parse_args()
     
    if(args.config_file is None or args.config_file==''):raise Exception(f'Must have config_file argument')
    if(not os.path.isfile(args.config_file)):raise Exception(f'config_file: {args.config_file} must be a valid file path !')

    config = init_config(args.config_file)
    deploy_config(config)
    

    

    

