
import logging.config
import os

import configparser 
from cdpq_utils.log import init_logging

logger = logging.getLogger(__name__)

class EnvInterpolation(configparser.BasicInterpolation):
    """Interpolation which expands environment variables in values."""

    def before_get(self, parser, section, option, value, defaults):
        value = super().before_get(parser, section, option, value, defaults)
        return os.path.expandvars(value)

#Have a unique config file is useful to store all config in one place.
#It should be one of the first thing to do !
#If config file has a log section, ti will try to init_logging_part !!
def init_config(config_file_path):
    global_config = load_config(config_file_path)
    if(global_config.has_section('log')):
        init_logging(global_config['log'].get('logging_file_path'))
    return global_config

def load_config(config_file_path):
    if(not os.path.isfile(config_file_path)): raise Exception(f'{config_file_path} is not a file !!')
    config = configparser.ConfigParser(interpolation=EnvInterpolation())
    config.optionxform = str
    logger.info(f'Load config file {config_file_path}')
    #We suppose config is in utf-8
    config.read(config_file_path, encoding='utf-8')
    return config
