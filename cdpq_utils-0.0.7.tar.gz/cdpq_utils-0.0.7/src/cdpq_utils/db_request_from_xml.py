import os
import logging.config
import xml.etree.ElementTree as ET
from datetime import datetime
from datetime import timedelta
from pathlib import Path

from cdpq_utils.db_request import open_connexion, close_connexion,execute_sql,fetch_sql
from cdpq_utils.db_request import db_configuration
from cdpq_utils.db_load_from_object import insert,create_table
from cdpq_utils.db_mock import dump_rows_to_file, load_mock_from_file

logger = logging.getLogger(__name__)

global_mock_directory = None

def apply_params(request,sql_params):
    sql = ''
    for line in request.splitlines():
        if( not line.strip().startswith('--') ):
            if(sql_params is not None):    
                for key, value in sql_params.items():
                    line = line.replace('{'+f'{key}'+'}',f'{value}')
            sql += line + '\n'
    return sql.strip()

def execute_sql_file(xml_file_path,sql_params):
    
    results = dict()
    db_mock_directory = dict()
    
    tree = ET.parse(xml_file_path)
    root = tree.getroot()
    
    for db_xml_config in root.iter('database'):
        
        db_configuration[db_xml_config.attrib['db_name']] = db_xml_config.attrib['connexion_string']
        #We can active mock functionnality directly inside the code with global_mock_directory
        #Or we can active mock functionnality in the config xml file by BD ...
        #Maybe config xml file should be on the dataset ... 
        if(global_mock_directory is not None):
            db_mock_directory[db_xml_config.attrib['db_name']] = global_mock_directory
            logger.info(f"Database {db_xml_config.attrib['db_name']} is 'mocked' from {global_mock_directory}")
        elif('db_mock_directory' in db_xml_config.attrib):
            db_mock_directory[db_xml_config.attrib['db_name']] = db_xml_config.attrib['db_mock_directory']
            logger.info(f"Database {db_xml_config.attrib['db_name']} is 'mocked' from {db_xml_config.attrib['db_mock_directory']}")
        else:
            logger.info(f"Load database configuration {xml_file_path}:{db_xml_config.attrib['db_name']}, {db_xml_config.attrib['connexion_string']}")

    element_id = 0
    for sql_command in root.iter('sql_command'):
        element_id += 1
        command_type = sql_command.attrib['command_type']
        db_name = sql_command.attrib['db_name']
        
        request_parameters = [ (p.attrib['name'],p.attrib['format']) for p in sql_command.findall('request_parameter')]
        #description = query.findtext('description')
        
        if(command_type == 'select'):
            dataset_name = sql_command.attrib['datasetname']
            if(db_mock_directory.get(db_name)):
                logger.info(f'Load dataset {dataset_name} from {db_mock_directory[db_name]}:{dataset_name}:block {element_id}')
                rows = load_mock_from_file(Path(os.path.join(db_mock_directory[db_name],f'{dataset_name}.mock')))
            else :
                logger.info(f'Select request {xml_file_path}:{db_name}:{dataset_name}:block {element_id}')
                request = sql_command.findtext('request')
                rows =  fetch_sql(db_name, apply_params(request,sql_params))   
            results.update({f'{dataset_name}':rows})
        elif(command_type in ['execute']):
            logger.info(f'Execute request {xml_file_path}:{db_name}:block {element_id}')
            dataset_name = sql_command.attrib['datasetname']
            request = sql_command.findtext('request')
            execute_sql(db_name,apply_params(request,sql_params))
        elif(command_type == 'open'):
            logger.info(f'Open connexion {xml_file_path}:{db_name}:block {element_id}')
            open_connexion(db_name)
        elif(command_type == 'close'):
            logger.info(f'Close connexion {xml_file_path}:{db_name}:block {element_id}')
            close_connexion(db_name)  
        elif(command_type == 'create_from_resultset'):
            logger.info(f'Create table {xml_file_path}:{db_name}:block {element_id}')
            table_name =  sql_command.attrib['table_name']
            resultset_name =  sql_command.attrib['resultset_name']
            create_table(db_name,table_name,results[resultset_name][0].cursor_description)
        elif(command_type == 'load_from_resultset'):
            logger.info(f'Load request {xml_file_path}:{db_name}:block {element_id}')
            table_name = sql_command.attrib['table_name']
            resultset_name = sql_command.attrib['resultset_name']
            insert(db_name,table_name,results[resultset_name])
        else:
            logger.warning('Unknown command_type {command_type}')  
    
    return results

def execute_sql_directory(path_directory,sql_params = None):
    all_data = dict()
    all_files = [f for f in Path(path_directory).glob('**\*') if f.is_file() and f.suffix in {'.xml'}]
    if(len(all_files) < 1):
        logger.warning(f'{path_directory} is empty !!')
        
    for file_path in sorted(all_files):
        logger.info(f'Execute xml file: {file_path}')
        all_data.update(execute_sql_file(file_path,sql_params))
    return all_data

