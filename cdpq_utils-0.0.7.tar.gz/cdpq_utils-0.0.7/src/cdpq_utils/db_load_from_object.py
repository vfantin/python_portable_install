import logging.config
import os


from datetime import datetime
from datetime import time
from datetime import date
from decimal import Decimal


from cdpq_utils.db_request import execute_sql,executemany_sql

logger = logging.getLogger(__name__)

#Not very usefull in fact
#I thing if you have to store data into a table, most of the time you want to manage the stockage type ... 
def create_table(db_name, table_name, cursor_description):
    col_names = ','.join([f'{row[0]} {convert_to_sql(row)}' for row in cursor_description])
    sql_create = f'CREATE TABLE {table_name}({col_names})'
    logger.info(f'Create a table:{table_name}')
    execute_sql(db_name,sql_create)

#!!!Very cool !!! 2 lines
def insert(db_name,table_name,rows):
    if(len(rows) == 0):
        logger.warning(f'Nothing to load {db_name}:{table_name}!')
    else:
        insert_sql = f"INSERT INTO {table_name}  VALUES ({','.join(['?' for col in rows[0]])})"
        executemany_sql(db_name,insert_sql,rows)
    
    logger.debug(f'Loaded {db_name}:{table_name}!')
    logger.debug(f'{rows}!')

#description is an array with 7 column
#[name, type_code, display_size, internal_size, precision, scale, null_ok]
#SQL_VARIANT not supported !!Logical ! 
#We could add a function with add_output_converter
def convert_to_sql(description):
    
    #name = description[0]
    type = description[1]
    size = description[3]
    precision = description[4]
    scale = description[5]
    if(type == Decimal):
        return f'DECIMAL({precision},{scale})'
    elif(type == float):
        return'FLOAT'
    elif(type == bool):
        return 'BIT'
    elif(type == int):
        return 'INT' if(size <= 10) else 'BIGINT'
    elif(type == str):
        return 'NVARCHAR(MAX)' if(size>8000) else f'NVARCHAR({size})'
    elif(type == date):
        return 'DATE'
    elif(type == datetime):
        #Maybe some problems with conversion fron a type to another ?!
        return 'DATETIME' if (size <= 23) else 'DATETIME2'
    elif(type == time):
        return 'TIME'
    elif(type == bytearray):
        return f'BINARY({size})'
    else:
        raise Exception(f'{description[0]} unknow type {type} !!')


