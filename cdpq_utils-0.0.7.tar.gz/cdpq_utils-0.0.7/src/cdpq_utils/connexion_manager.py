import time
import logging.config

import cdpq_utils.config as cf

logger = logging.getLogger(__name__)

#config = load_global_config()
#Activate  
management_is_active = False 

#Max number of retry  
max_retry = 3 

#Time to wait before a retry for a good connexion OR a direct retry !
waiting_time = 3 

#Useful for test
nb_error = 0

def manage_connection(func):
    def decorator (*args, **kwargs):
        global nb_error 
        if management_is_active:
            for attempt in range(1,max_retry+2):
                try:
                    return func(*args, **kwargs)
                except Exception as ex:
                    nb_error += 1
                    manage_exception(attempt,ex)
        else:
            return func(*args, **kwargs)
    
    return decorator 
    
def manage_exception(attempt, ex):
    if(max_retry!=0):
        if(attempt == 1): logger.info(f'SQLException --> {ex}')
        
        if(attempt == max_retry+1):
            logger.info(f'Raise exception after try {attempt} .')
            raise ex
        else:
            logger.info(f'Wait {waiting_time} seconds after try {attempt} .')
            time.sleep(waiting_time)
    else:
        raise ex

