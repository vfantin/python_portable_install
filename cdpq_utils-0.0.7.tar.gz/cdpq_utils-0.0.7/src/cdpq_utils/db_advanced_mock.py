import os
import logging.config
from pathlib import Path
from shutil import rmtree

from cdpq_utils.db_request_from_xml import execute_sql_file,execute_sql_directory
from cdpq_utils.db_mock import dump_rows_to_file

logger = logging.getLogger(__name__)

#To avoid circular reference, it's more logical tu put this function here than inside db_mock
def dump_xmlfile_to_dir(file_path, sql_param, output_directory):
    if(not os.path.isfile(file_path)): raise Exception(f'{file_path} is not a file !!')
    if(not os.path.isdir(output_directory)): raise Exception(f'{output_directory} is not a directory !!')
    resulsets = execute_sql_file(file_path,sql_param)
    {dump_rows_to_file(os.path.join(output_directory,f'{name}.mock'),resulsets[name]) for name in resulsets}

def dump_sql_directory_to_dir(sql_directory,output_directory,sql_params = None):
    resulsets = execute_sql_directory(sql_directory,sql_params)
    for dataset_name in resulsets:
        dump_rows_to_file(os.path.join(output_directory,f'{dataset_name}.mock'),resulsets[dataset_name])

def mock_input_data(mock_config_file):
    mock_input_directory = mock_config_file['mock']['mock_input_directory']
    mock_sql_directory = mock_config_file['mock']['mock_sql_directory'] 

    if(os.path.exists(mock_input_directory)): rmtree(mock_input_directory)
    os.mkdir(mock_input_directory)
    
    sql_params = None
    if(mock_config_file.has_section('sql')):
        sql_params = {param:eval(mock_config_file['sql'][param]) for param in mock_config_file['sql']}

    dump_sql_directory_to_dir(mock_sql_directory,mock_input_directory,sql_params)
